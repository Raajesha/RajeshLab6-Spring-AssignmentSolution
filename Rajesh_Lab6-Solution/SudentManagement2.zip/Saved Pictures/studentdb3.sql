create database studentdb2;
use studentdb2;
select * from roles;
select * from student;
select * from users;
select * from users_roles;
insert into users values(1,'$2a$12$vKSg.fryG3hTeUrCb.xBoeQCQile2WUNjPdbcSrQKHW7ASvHhUOwC','user1');
insert into users values(2,'$2a$12$vKSg.fryG3hTeUrCb.xBoeQCQile2WUNjPdbcSrQKHW7ASvHhUOwC','user2');
insert into roles values(1,`ADMIN`); 
insert into roles values(2,`USER`); 
use studentdb2;
insert into users_roles
values(1,1);
insert into users_roles
values(2,2);